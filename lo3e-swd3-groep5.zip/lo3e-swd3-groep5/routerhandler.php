<?php 
require_once './vendor/autoload.php';

use Src\Router\Router;

$url = isset($_GET['url']) ? rtrim($_GET['url'], '/') : 'register';


$router = new Router();
$router->handleRequest($url);

?>
