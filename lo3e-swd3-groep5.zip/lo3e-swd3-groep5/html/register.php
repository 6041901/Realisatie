<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <div class="form-container">
        <h1>Register</h1>
        <div class="form-box">
            <div class="form">
                <form method="post" id="register-form">
                    <input type="text" id="username" name="username" placeholder="Gebruikersnaam" class="answer-field"><br>
                    <input type="password" id="password" name="password" placeholder="Wachtwoord" class="answer-field"><br>
                    <input type="text" id="answer" name="answer" placeholder="Hoe heette je eerste huisdier?" class="answer-field"><br>
                    <input type="submit" id="register-button" name="submit" placeholder="Submit" class="submit"><br>
                    <a href="login.php" id="login-link">Ben je al een gebruiker?</a>
                    <script src="../src/js/user.js"></script>
                </form>
            </div>
        </div>
    </div>
    <div class="form-container">
        <h2>Login</h2>
        <form id="form">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Gebruikersnaam" class="answer-field"><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Wachtwoord" class="answer-field"><br>

            <label for="answer">Answer:</label>
            <input type="text" id="answer" name="answer" placeholder="Hoe heette je eerste huisdier?" class="answer-field"><br>

            <button id="login-button" type="button">Login</button>
            <a href="register.php" id="register-link">Nog geen account?</a>

            <input type="submit" id="register-button" name="submit" placeholder="Submit" class="submit"><br>
        </form>
    </div>
</body>

</html>