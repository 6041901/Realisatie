<?php require_once __DIR__ . '/../auth.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activities</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="../src/js/add-modal.js" type="module"></script>
    <script src="../src/js/edit-modal.js" type="module"></script>
    <script type="module" src="../src/js/Activity/script.js"></script>
</head>

<body>
    <div id="create-new-activity">
        <div id="search-filter-div">
            <p>Search activities</p>
            <input id="search-activities" type="text"></input>
        </div>
        <p id="activity-create">Create New Activity</p>
    </div>

    <div id="add-modal">
        <div id="modal-card">
            <div class="add-modal-close">
                <h2 id="add-close">&times;</h2>
            </div>
            <h2 style="padding-bottom: 10px;"> Create New Activity</h2>
            <form id="activity-form" action="">
                <input type="text" id="activity-title" name="title" placeholder="Titel" class="activity-field"><br>
                <input type="date" id="activity-date" name="date" placeholder="Datum" class="activity-field"><br>
                <input type="time" id="activity-time" name="time" placeholder="Tijd" class="activity-field"><br>
                <input type="text" id="activity-sort" name="sort" placeholder="Soort activiteit" class="activity-field"><br>
                <input type="text" id="activity-location" name="location" placeholder="Locatie" class="activity-field"><br>
                <input type="text" id="activity-city" name="city" placeholder="City" class="activity-field"><br>
                <input type="text" id="activity-description" name="description" placeholder="Beschrijving" class="activity-field"><br>
                <input type="text" id="activity-notes" name="notes" placeholder="Notitie" class="activity-field"><br>
            </form>
            <div id="save-activity">
                <h2 id="add-modal-save">&check;</h2>
            </div>
        </div>
    </div>
    
    <div id="edit-modal">
        <div id="modal-card">
            <div class="edit-modal-close">
                <h2 id="edit-close">&times;</h2>
            </div>
            <h2 style="padding-bottom: 10px;"> Edit Activity</h2>
            <form action="">
                <input type="text" id="edit-activity-title" name="title" placeholder="Titel" class="activity-field"><br>
                <input type="date" id="edit-activity-date" name="date" placeholder="Datum" class="activity-field"><br>
                <input type="time" id="edit-activity-time" name="time" placeholder="Tijd" class="activity-field"><br>
                <input type="text" id="edit-activity-sort" name="sort" placeholder="Soort activiteit" class="activity-field"><br>
                <input type="text" id="edit-activity-location" name="location" placeholder="Locatie" class="activity-field"><br>
                <input type="text" id="edit-activity-city" name="city" placeholder="City" class="activity-field"><br>
                <input type="text" id="edit-activity-description" name="description" placeholder="Beschrijving" class="activity-field"><br>
                <input type="text" id="edit-activity-notes" name="notes" placeholder="Notitie" class="activity-field"><br>
            </form>
            <div id="update-activity">
                <h2 id="edit-modal-save">&check;</h2>
            </div>
        </div>
    </div>

    <div id="activities">

    </div>
    <template id="activity-template">
        <div class="activity-card">
            <div class="information-container">
                <div class="information-box">
                    <h2 class="activity-title">Titel Activiteit</h2>
                    <br>
                    <p class="activity-date">Datum: 19/2/2025</p>
                    <p class="activity-time">Tijd: 19:00 </p>
                    <p class="activity-sort">Soort: Binnen</p> <!-- // binnen buiten -->
                    <p class="activity-location">Locatie: Betaplein 18</p>
                    <p class="activity-city">Stad: Leiden</p>
                    <br>
                </div>
                <p class="activity-weather">Weer: nvt</p> <!-- alleen van belang als buiten - bij binnen niet tonen -->
                <br>
            </div>
            <!-- <p id="activity-participants">Lijst met deelnemers</p> // lijst met deelnemers - enkel voor de 'werknemer' tonen, niet voor de normale mens -->
            <p class="activity-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec rutrum, tellus sed tincidunt maximus, felis tellus congue est, et euismod quam lectus ut justo. Nam sollicitudin dapibus ex</p> <br>
            <p class="activity-notes">Note: <span id="notes-color"> Wij raden u aan om een korte broek te dragen </span></p> <!-- // extra notes - niet required -->
            <?php if (isset($_SESSION['userType']) && $_SESSION['userType'] == 1): ?>
                <div class="activity-admin">
                    <p class="admin-edit">Edit</p>
                    <p class="admin-delete">Delete</p>
                </div>
            <?php endif; ?>
        </div>
    </template>
</body>

</html>