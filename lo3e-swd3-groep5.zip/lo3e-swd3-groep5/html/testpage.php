<?php

namespace Src\Router;

use Src\Database\GeneralizationDatabase;

require_once __DIR__ . '/../vendor/autoload.php';

require_once __DIR__ . '/../src/Database/GeneralizationDatabase.php';

$db = new \Src\Database\GeneralizationDatabase();

class Usernames extends GeneralizationDatabase {
    public function getUsernames() {
        $query = "SELECT username FROM user";
        return $this->selectData($query);
    }
}

$usernamesData = new Usernames();
$usernames = $usernamesData->getUsernames();
print_r($usernames);