<?php
namespace Src\Database;

require_once __DIR__ . '/../../vendor/autoload.php'; 

use PDO;
use Src\Database\StaticDatabase;
use Src\Interfaces\DatabaseOperations;

abstract class DbHandler implements DatabaseOperations {
    private $connection;

    public function __construct() {
        $this->connection = StaticDatabase::getInstance()->getConnection();
    }

    public function insertData($query, $params) {
        $stmt = $this->connection->prepare($query);
        return $stmt->execute($params);
    }

    public static function selectData($query, $params = []) {
        $db = StaticDatabase::getInstance();
        $connection2 = $db->getConnection();
        if (!empty($params)) {
            $stmt = $connection2->prepare($query);
            $stmt->execute($params);
        } else {
            $stmt = $connection2->query($query);
        }
        return $stmt->fetchAll(PDO::FETCH_ASSOC); 
    }
    
    

    public function updateData($query, $params) {
        $stmt = $this->connection->prepare($query);
        return $stmt->execute($params);
    }

    public function deleteData($query, $params) {
        $stmt = $this->connection->prepare($query);
        return $stmt->execute($params);
    }
}
?>