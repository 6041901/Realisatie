<?php 
namespace Src\Database;

require_once __DIR__ . '/../../vendor/autoload.php'; 

use PDO;
use PDOException;

class StaticDatabase {
    private static $instance = null;
    private $connection;

    private function __construct() {
        try {
            $host = 'db'; 
            $port = '3306';
            $dbname = 'local';
            $username = 'user';
            $password = 'root';
            
            $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
            
            $this->connection = new PDO($dsn, $username, $password);
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Database connection failed. Please try again later.");
        }
    }

    public static function getInstance() {
        if(self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }
}

?>