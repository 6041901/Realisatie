<?php

namespace Src\Database;

require_once __DIR__ . '/../../vendor/autoload.php';

use PDO;
use PDOException;

class GeneralizationDatabase {
    private $connection;

    public function __construct() { 
        try {
            $host = 'db';
            $dbname = 'local';
            $username = 'user';
            $password = 'root';

            $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";

            $this->connection = new PDO($dsn, $username, $password);
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo ("Connection failed: " . $e->getMessage());
            die;
        }
    }

    public function selectData($query) {
        try {
            $stmt = $this->connection->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo ("Query failed: " . $e->getMessage());
            return;
        }
    }
}