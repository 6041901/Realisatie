<?php 
namespace Src\Interfaces;

require_once __DIR__ . '/../../vendor/autoload.php'; 

interface DatabaseOperations {
    public function insertData($query, $params);

    public static function selectData($query, $params = []);

    public function updateData($query, $params);

    public function deleteData($query, $params);
}

?>