<?php

require_once __DIR__ . '/../../vendor/autoload.php';

use Src\Database\DbHandler;

class User extends DbHandler
{
    public function register($username, $password, $answer, $userType)
    {
        $query = "INSERT INTO user (username, password, safety_answer, user_type) VALUES (:username, :password, :safety_answer, :user_type)";
        $params = ['username' => $username, 'password' => $password, 'safety_answer' => $answer, 'user_type' => $userType];

        return $this->insertData($query, $params);
    }

    public function checkLogin($username, $password)
    {
        $query = "SELECT `password`, `user_type` FROM `user` WHERE `username` = ?";
        $result = DbHandler::selectData($query, [$username]);

        if ($result) {
            $hashedPassword = $result[0]['password'];
            if (password_verify($password, $hashedPassword)) {
                session_start();
                echo json_encode(['success' => true]);

                $_SESSION['user_logged_in'] = true;
                $_SESSION['username'] = $username;
                $_SESSION['userType'] = $result[0]['user_type'];
            } else {
                echo json_encode(['success' => false, 'message' => 'Incorrect password']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'User not found']);
        }

        exit;
    }
}

if (isset($_POST['register'])) {
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];
    $password_hashed = password_hash($password, PASSWORD_BCRYPT);
    $answer = htmlspecialchars($_POST['answer']);
    $userType = htmlspecialchars($_POST['userType']);

    $user = new User();
    $result = $user->register($username, $password_hashed, $answer, $userType);

    if ($result) {
        echo json_encode([
            'success' => true,
            'message' => 'Registration successful!'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Registration failed, please try again.'
        ]);
    }
    exit;
}

if (isset($_POST['login'])) {
    $user = new User();
    $user->checkLogin(htmlspecialchars($_POST['username']), $_POST['password']);
}
