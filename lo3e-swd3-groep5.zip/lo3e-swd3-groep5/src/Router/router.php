<?php 
namespace Src\Router;

class Router {
    public function handleRequest($page) {
        $filePath = __DIR__ . '/../../html/' . $page . '.php';

        if (file_exists($filePath)) {
            require $filePath;
        } else {
            http_response_code(404);
            require __DIR__ . '/../../html/404.php';
        }
    }
}
?>
