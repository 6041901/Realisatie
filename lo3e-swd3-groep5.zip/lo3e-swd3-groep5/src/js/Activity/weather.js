export class Weather {
    constructor(date, city) {
        this.baseUrl = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline";
        this.apiKey = "VZRPZ73AEB45KLSJYUPYR5ZF7";
        this.city = city;
        this.date = date;
    }

    async fetchWeather() {
        try {
            const url = `${this.baseUrl}/${this.city}/${this.date}?unitGroup=metric&include=days&key=${this.apiKey}&contentType=json`;
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error("Failed to fetch weather data");
            }
            const data = await response.json();
            return data.days[0] || null;
        } catch (error) {
            console.error("Error:", error);
            return null;
        }
    }
}