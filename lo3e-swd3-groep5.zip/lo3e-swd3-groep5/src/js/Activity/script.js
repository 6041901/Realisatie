import { Activity } from "./activity.js";
import { retrieveActivities, saveActivity, updateActivity, searchAndFilterActivities } from "./api.js";
import { closeAddModal } from "../add-modal.js";
import { closeEditModal } from "../edit-modal.js";
import { Weather } from "./weather.js";
import { renderActivities } from "./ui.js";

let saveButton = document.getElementById('save-activity');
let searchBox = document.getElementById('search-activities');
let searchTimeout;

saveButton.addEventListener('click', async (event) => {
    event.preventDefault();

    let title = document.getElementById('activity-title').value;
    let description = document.getElementById('activity-description').value;
    let date = document.getElementById('activity-date').value;
    let time = document.getElementById('activity-time').value;
    let location = document.getElementById('activity-location').value;
    let city = document.getElementById('activity-city').value;
    let sortActivity = document.getElementById('activity-sort').value;
    let notes = document.getElementById('activity-notes').value;
    let weatherInfo = '';

    if (!title || !description || !date || !time || !location || !city || !sortActivity) {
        alert("Please fill in all the required fields!");
        return;
    }

    if (sortActivity === "buiten") {
        const weather = new Weather(date, city);
        const weatherData = await weather.fetchWeather();

        let temperature = weatherData ? weatherData.temp : "N/A";
        let conditions = weatherData ? weatherData.conditions : "Unknown";

        weatherInfo = weatherData ? `${temperature}°C, ${conditions}` : "Weer is niet bekend";
    } else {
        weatherInfo = "Weer is niet van toepassing";
    }


    let currActivity = new Activity(title, description, date, time, location, city, sortActivity, notes, weatherInfo);

    currActivity.saveActivity(currActivity).then((result) => {
        if (result === "succes") {
            Activity.retrieveActivities();
            closeAddModal();
        } else {
            console.log(result);
        }
    });

});

let updateButton = document.getElementById('edit-modal-save');
let activityId = 0;

export function setEditId(id) {
    activityId = id;
}

updateButton.addEventListener('click', async (event) => {
    event.preventDefault();

    let title = document.getElementById('edit-activity-title').value;
    let description = document.getElementById('edit-activity-description').value;
    let date = document.getElementById('edit-activity-date').value;
    let time = document.getElementById('edit-activity-time').value;
    let location = document.getElementById('edit-activity-location').value;
    let city = document.getElementById('edit-activity-city').value;
    let sortActivity = document.getElementById('edit-activity-sort').value;
    let notes = document.getElementById('edit-activity-notes').value;
    let weatherInfo = '';

    if (!title || !description || !date || !time || !location || !city || !sortActivity) {
        alert("Please fill in all the required fields!");
        return;
    }

    if (sortActivity === "buiten") {
        const weather = new Weather(date, city);
        const weatherData = await weather.fetchWeather();

        let temperature = weatherData ? weatherData.temp : "N/A";
        let conditions = weatherData ? weatherData.conditions : "Unknown";

        weatherInfo = weatherData ? `${temperature}°C, ${conditions}` : "Weer is niet bekend";
    } else {
        weatherInfo = "Weer is niet van toepassing";
    }

    let newActivity = new Activity(title, description, date, time, location, city, sortActivity, notes, weatherInfo);

    newActivity.updateActivity(activityId, newActivity).then(() => {

        Activity.retrieveActivities();
        closeEditModal();

    });

});

/**
 * Listens to keyinput to search for activities
 */
searchBox.addEventListener('keyup', () => {
    clearTimeout(searchTimeout); 
    searchTimeout = setTimeout(() => {
        Activity.searchAndFilterActivities(searchBox.value).then((result) => {
            renderActivities(result, true);
        });
    }, 1000); 
});

document.addEventListener('DOMContentLoaded', () => {
    Activity.retrieveActivities();
});