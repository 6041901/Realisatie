import { renderActivities } from "../Activity/ui.js";

export class Activity {
    title;
    description;
    date;
    time;
    location;
    city;
    sortActivity;
    notes;
    weatherInfo = '';

    constructor(title = '', description = '', date = '', time = '', location = '', city = '', sortActivity = '', notes = '', weatherInfo = '') {
        this.title = title;
        this.description = description;
        this.date = date;
        this.time = time;
        this.location = location;
        this.city = city;
        this.sortActivity = sortActivity;
        this.notes = notes;
        this.weatherInfo = weatherInfo;
    }

    async saveActivity(activity) {
        let formData = new FormData();
        formData.append("action", "saveActivity");
        formData.append("activityData", JSON.stringify(activity));

        try {
            const response = await fetch("../src/Activity/activity.php", { method: "POST", body: formData });
            const data = await response.json();
            return data.result === "succes" ? "succes" : "failure";
        } catch (error) {
            console.error("Error:", error);
            return "error";
        }
    }

    async updateActivity(activityId, activity) {
        let formData = new FormData();
        formData.append("action", "updateActivity");
        formData.append("activityId", activityId);
        formData.append("activityData", JSON.stringify(activity));

        try {
            const response = await fetch("../src/Activity/activity.php", { method: "POST", body: formData });
            const data = await response.json();
            return data.result === "succes" ? "success" : "failure";
        } catch (error) {
            console.error("Fetch error:", error);
            return "error";
        }
    }

    async retrieveActivity(activityId) {
        let formData = new FormData();
        formData.append("action", "retrieveActivity");
        formData.append("data", activityId);

        try {
            const response = await fetch("../src/Activity/activity.php", { method: "POST", body: formData });
            return await response.json();
        } catch (error) {
            console.error("Error:", error);
            return null;
        }
    }

    static async retrieveActivities() {
        let formData = new FormData();
        formData.append("action", "retrieveActivities");

        try {
            const response = await fetch("../src/Activity/activity.php", { method: "POST", body: formData });
            const data = await response.json();
            if (!data.empty) {
                renderActivities(data.activities, true);
            }
            return data.empty ? [] : data.activities;
        } catch (error) {
            console.error("Error:", error);
            return [];
        }
    }

    static async searchAndFilterActivities(query, filter = '') {
        let formData = new FormData();
        formData.append("action", "searchAndFilterActivity");
        formData.append("search", query);
        formData.append("filter", filter);

        try {
            const response = await fetch("../src/Activity/activity.php", { method: "POST", body: formData });
            const data = await response.json();
            return data.activities;
        } catch (error) {
            console.error("Error:", error);
            return [];
        }
    }
}