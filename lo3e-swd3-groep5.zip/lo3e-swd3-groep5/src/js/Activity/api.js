import { renderActivities } from "./ui.js";

//LEGACY CODE

/**
 * Function to save activity in the database
 * @param {Object} activity - Object of the activity you want saved 
 */
export function saveActivity(activity) {
    let formData = new FormData();
    formData.append("action", "saveActivity");
    formData.append("activityData", JSON.stringify(activity));

    return fetch("../src/Activity/activity.php", {
        method: "POST",
        body: formData,
    })
        .then(response => response.json())
        .then(data => {
            if (data.result === "succes") {
                return "succes";
            } else {
                return "failure";
            }
        })
        .catch(error => {
            console.error("Error:", error);
            return "error";
        });
}

/**
 * Function to update an activity in the database
 * @param {number} activityId - The ID of the activity to update
 * @param {Object} activity - Object with updated activity data
 */
export function updateActivity(activityId, activity) {
    let formData = new FormData();
    formData.append("action", "updateActivity");
    formData.append("activityId", activityId);
    formData.append("activityData", JSON.stringify(activity));

    return fetch("../src/Activity/activity.php", {
        method: "POST",
        body: formData,
    })
        .then(response => response.json())
        .then(data => {
            console.log("Server response:", data);
            if (data == "succes") {
                return "success";
            } else {
                console.error("Error updating activity:", data.error);
            }
        })
        .catch(error => console.error("Fetch error:", error));
}

/**
 * Function to retrieve the activity from the database
 * @param {int} activityId - Id of the activity
 */
export function retrieveActivity(activityId) {
    let formData = new FormData();
    formData.append("action", "retrieveActivity");
    formData.append("data", activityId);

    fetch("../src/Activity/activity.php", {
        method: "POST",
        body: formData,
    })
        .then(response => response.json())
        .then(data => {
            //Action if retrieved correctly
        })
        .catch(error => console.error("Error:", error));
}

/**
 * Function to retrieve the activities from the database
 */
export function retrieveActivities() {
    let formData = new FormData();
    formData.append("action", "retrieveActivities");

    fetch("../src/Activity/activity.php", {
        method: "POST",
        body: formData,
    })
        .then(response => response.json())
        .then(data => {
            if (data.empty) {
                return;
            } else {
                renderActivities(data.activities, true);
            }
        })
        .catch(error => console.error("Error:", error));
}

/**
 * Function to search and filter for activities
 * 
 * @param {string} query 
 * @param {string} filter 
 */
export function searchAndFilterActivities(query, filter = '') {
    let formData = new FormData();
    formData.append("action", "searchAndFilterActivity");
    formData.append("search", query);
    formData.append("filter", filter);

    return fetch("../src/Activity/activity.php", {
        method: "POST",
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        return data.activities;
    })
    .catch(error => console.error("Error:", error));
}