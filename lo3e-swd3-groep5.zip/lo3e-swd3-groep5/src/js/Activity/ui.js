/**
 * 
 * @param {array} activities - activities to create templates
 * @param {boolean} empty - If set to true, it will empty the activities page.
 */
export function renderActivities(activities, empty = false) {
    const activityElement = document.getElementById('activities');
    const activityTemplate = document.getElementById('activity-template');

    if (empty == true) {
        activityElement.innerHTML = "";
    }

    activities.forEach(activity => {
        let clone = activityTemplate.content.cloneNode(true);
        const editButton = clone.querySelector('.admin-edit');
        const deleteButton = clone.querySelector('.admin-delete');

        clone.querySelector('.activity-title').textContent = activity.title;
        clone.querySelector('.activity-description').textContent = activity.description;
        clone.querySelector('.activity-date').textContent = activity.date;
        clone.querySelector('.activity-time').textContent = activity.time;
        clone.querySelector('.activity-location').textContent = activity.location;
        clone.querySelector(".activity-city").textContent = activity.city;
        clone.querySelector('.activity-sort').textContent = activity.sort_activity;
        clone.querySelector('.activity-notes').textContent = activity.notes;
        clone.querySelector('.activity-weather').textContent = activity.weather_info;

        if (editButton) {
            editButton.setAttribute("data-id", activity.id);
            editButton.addEventListener('click', () => populateEditForm(activity));
        }

        if (deleteButton) {
            deleteButton.setAttribute("data-id", activity.id);
        }
        
        activityElement.appendChild(clone);
    });
}

function populateEditForm(activity) {
    document.querySelector('#edit-activity-title').value = activity.title;
    document.querySelector('#edit-activity-description').value = activity.description;
    document.querySelector('#edit-activity-date').value = activity.date;
    document.querySelector('#edit-activity-time').value = activity.time;
    document.querySelector('#edit-activity-location').value = activity.location;
    document.querySelector('#edit-activity-city').value = activity.city;
    document.querySelector('#edit-activity-sort').value = activity.sort_activity;
    document.querySelector('#edit-activity-notes').value = activity.notes;
}