const addModal = document.getElementById("add-modal");
const createButton = document.getElementById("activity-create");
const addClose = document.getElementById("add-close");

createButton.addEventListener("click", openAddModal);

export function openAddModal() {
    addModal.style.display = "flex";
}

addClose.addEventListener("click", closeAddModal);

export function closeAddModal() {
    addModal.style.display = "none";
}