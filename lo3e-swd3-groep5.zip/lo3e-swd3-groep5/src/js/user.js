class User {

    constructor() {
        document.getElementById('login-button') && document.getElementById('login-button').addEventListener('click', this.checkLogin.bind(this)); // For login page
        document.getElementById('register-button') && document.getElementById('register-button').addEventListener('click', this.checkFormValue.bind(this)); // For register page
    }

    checkFormValue(event) {
        event.preventDefault();
        let username = document.getElementById("username").value.trim();
        let password = document.getElementById("password").value.trim();
        let answer = document.getElementById("answer").value.trim();
        const urlParams = new URLSearchParams(window.location.search);
        let userType = urlParams.get('link');

        if (userType) {
            userType = 0;
        } else {
            userType = 1;
        }

        if (username === "" || password === "" || answer === "") {
            alert("Vul alle gevraagde gegevens in");
            return;
        } else {
            let formData = new FormData();
            formData.append("register", "true");
            formData.append("username", username);
            formData.append("password", password);
            formData.append("answer", answer);
            formData.append("userType", userType);

            fetch("../src/User/user.php", {
                    method: "POST",
                    body: formData,
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = "/login";
                    }
                })
                .catch(error => console.error("Error:", error));
        }
    }

    checkLogin(event) {
        event.preventDefault();
        let username = document.getElementById("username").value.trim();
        let password = document.getElementById("password").value.trim();

        if (username === "" || password === "") {
            alert("Vul alle gevraagde gegevens in");
            return;
        } else {
            let formData = new FormData();
            formData.append("login", "true");
            formData.append("username", username);
            formData.append("password", password);

            fetch("../src/User/user.php", {
                    method: "POST",
                    body: formData,
                })
                .then(response => response.json())
                .then(data => {
                    if (!data.success) {
                        alert(data.message);
                    } else {
                        window.location.href = "/activities";
                    }
                })
                .catch(error => console.error("Error:", error));
        }
    }
}

const user = new User();