import { setEditId } from "./Activity/script.js"; 

const editModal = document.getElementById("edit-modal");
const editClose = document.getElementById("edit-close");
const editButton = document.getElementById("edit-modal-save");

document.getElementById("activities").addEventListener("click", (event) => {
    if (event.target && event.target.className === "admin-edit") {
        let activityId = event.target.getAttribute("data-id");
        openEditModal(activityId);

        setEditId(activityId);
        console.log(activityId);
    }
});

editButton.addEventListener("click", openEditModal);

export function openEditModal() {
    editModal.style.display = "flex";
}

editClose.addEventListener("click", closeEditModal);

export function closeEditModal() {
    editModal.style.display = "none";
    document.getElementById("activity-form").reset();
}