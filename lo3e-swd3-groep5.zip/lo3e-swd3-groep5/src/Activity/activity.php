<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use Src\Database\DbHandler;

class Activity extends DbHandler
{

    /**
     * Function to save an activity
     *
     * @param [array] $activityData Array with the activity data
     * @return void
     */
    public function saveActivity($activityData)
    {
        $query = "INSERT INTO activities (title, description, date, time, location, city, sort_activity, notes, weather_info) VALUES (:title, :description, :date, :time, :location, :city, :sort_activity, :notes, :weather_info)";

        $params = [
            'title' => $activityData['title'],
            'description' => $activityData['description'],
            'date' => $activityData['date'],
            'time' => $activityData['time'],
            'location' => $activityData['location'],
            'city' => $activityData['city'],
            'sort_activity' => $activityData['sortActivity'],
            'notes' => $activityData['notes'],
            'weather_info' => $activityData['weatherInfo']
        ];

        return $this->insertData($query, $params);
    }

    /**
     * Funtion to retrieve all activities
     *
     * @return array
     */
    public function updateActivity($activityData, $activityId)
    {
        $query =
            "UPDATE activities 
            SET title = :title, 
            description = :description,
            date = :date,
            time = :time,
            location = :location,
            city = :city,
            sort_activity = :sort_activity,
            notes = :notes,
            weather_info = :weather_info
            WHERE id = :activityId";

        $params = [
            'title' => $activityData['title'],
            'description' => $activityData['description'],
            'date' => $activityData['date'],
            'time' => $activityData['time'],
            'location' => $activityData['location'],
            'city' => $activityData['city'],
            'sort_activity' => $activityData['sortActivity'],
            'notes' => $activityData['notes'],
            'weather_info' => $activityData['weatherInfo'],
            'activityId' => $activityId,
        ];


        return $this->updateData($query, $params);
    }

    // public function deleteActivity($activityId)
    // {
    //     $query = "DELETE FROM activities WHERE id = :activityId";

    //     $params = [
    //         'activityId' => $activityId,
    //     ];

    //     return $this->deleteData($query, $params);
    // }

    public static function getAllActivities()
    {
        $query = "SELECT * FROM activities";
        return DbHandler::selectData($query);
    }

    /**
     * Function to search and filter for activities
     *
     * @param [string] $query search input by user
     * @param [string] $filter filter selected by the user
     * @return array
     */
    public function searchAndFilterActivity($query, $filter) {
        $finalQuery = '%' . $query . '%';
        if(empty($filter)) {
            $query = "SELECT * FROM activities
                WHERE CONCAT(
                title, ' ', 
                description, ' ', 
                date, ' ', 
                time, ' ', 
                location, ' ', 
                sort_activity, ' ', 
                notes, ' ', 
                weather_info
            ) LIKE :searchQuery";
            return DbHandler::selectData($query, ['searchQuery' => $finalQuery]);
        }else {
            //Filter option still needs to be added
        }
    }
}

if ($_POST) {
    $activity = new Activity();
    if ($_POST['action'] == 'saveActivity') {
        $activityData = json_decode($_POST['activityData'], true);

        if ($activityData === null) {
            echo json_encode(['result' => 'failure', 'message' => 'Invalid JSON']);
            exit;
        }

        $result = $activity->saveActivity($activityData);
        if ($result) {
            echo json_encode(['result' => 'succes']);
        }
    } else if ($_POST['action'] == 'retrieveActivities') {
        $result = Activity::getAllActivities();
        if (empty($result)) {
            echo json_encode(['empty' => true]);
        } else {
            echo json_encode(['activities' => $result]);
        }
    } else if ($_POST['action'] == 'updateActivity') {
        $result = $activity->updateActivity(json_decode($_POST['activityData'], true), $_POST['activityId']);
        if ($result) {
            echo json_encode(['result' => 'succes']);
        }
    } else if($_POST['action'] == 'searchAndFilterActivity') {
        $result = $activity->searchAndFilterActivity($_POST['search'], $_POST['filter']);
        echo json_encode(['activities' => $result]);
    }
}
